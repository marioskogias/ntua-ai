public class canNotReach extends Exception {

	public canNotReach(String s) {
		super(s);
	}

	public String getMessage() {
		return super.getMessage();
	}
}
